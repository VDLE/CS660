int foo(int a);

void main()
{
  foo(1);
}

int foo(int a)
{

}
