void main ()
{
   int a = 1;
   if ( a < 0 )
   {
     
   }
} 
