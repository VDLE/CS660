void main()
{
   int a[5];
   a[1] = 1;
}
