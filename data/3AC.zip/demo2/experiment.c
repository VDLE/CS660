int a;
int b = 5; 
