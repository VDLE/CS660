void main()
{
  int a = 5;
  int c;
  int b;
  c = a + b + 5; 
}


