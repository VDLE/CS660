int a;
int main()
{
  int a;
  char a;
  b = 1;

}
