char a = 1.1;
int main()
{
 int** a = 1;
}
