
class SymbolTableError(Exception):
  pass

class SymbolTableWarning(Exception):
  pass

