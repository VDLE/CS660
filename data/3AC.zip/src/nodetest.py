from asttree import *

a = Node()
b = Node()

print a.floatTicketCounter.GetNextTicket()
print b.floatTicketCounter.GetNextTicket()