void foo(int); 
typedef int happy_halloween;
int main()
{
   happy_halloween pumpkin;
   int a;
   int b;
   char c;
   char d[50][50];
   int* e;
   int i = 0;
   int j = 0;
   for(i = 0; i < 10; i++)
   {
     int somethinghere;
     for (j = 0; j < 10; j++)
     {
     a = 1;
     }@
   }
}


void foo(int a)
{
  happy_halloween jack;
}@


