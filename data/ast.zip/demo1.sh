python driver.py -p parselog1.txt -t token1.txt demo1/scope.c > out1.log 
python driver.py -p parselog2.txt -t token2.txt demo1/iterfact.c > out2.log
python driver.py -p parselog3.txt -t token3.txt demo1/syntaxerror.c > out3.log
python driver.py -p parselog4.txt -t token4.txt demo1/lexicalerror.c > out4.log
python driver.py -p parselog5.txt -t token5.txt demo1/declaretest.c > out5.log
